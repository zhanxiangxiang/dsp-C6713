#define	CHIP_6713 1

#include <csl.h>
#include <csl_emif.h>
#include <csl_irq.h>
#include <stdio.h>


#define PLLCSR  *((Uint32*)0x01B7C100)
#define PLLM    *((Uint32*)0x01B7C110)
#define PLLDIV0 *((Uint32*)0x01B7C114)	//REF CLOCK
#define PLLDIV1 *((Uint32*)0x01B7C118)	//CPU CLOCK
#define PLLDIV2 *((Uint32*)0x01B7C11C)	//PER CLOCK
#define PLLDIV3 *((Uint32*)0x01B7C120)	//EMIF CLOCK
#define OSCDIV1 *((Uint32*)0x01B7C124)	//SYS CLOCK
#define CTL0 *((Uint32*)0x01940000)


void delay(int ttt)//uint 100us
{
	int i,j;
	for(i=0;i<ttt;i++)
	{
//		for(j=0;j<2000;j++)	//1716
			asm(" nop ");
	}
}

void InitEmif()
{
	EMIF_Config emif_cfg = {
	  0x00003778, /* gblctl */
	  0xffffff33, /* cectl0 */
	  0xffffff03, /* cectl1 */
	  0xffffff43, /* cectl2 */
	  0xffffff13, /* cectl3 */
	  0x57116000, /* sdctl  */
	  0x00000400, /* sdtim  */
	  0x00000000  /* sdext  */
	};

	EMIF_config(&emif_cfg);
}


void main()
{   

    CTL0 &= 0xFFFFFFFE;
//	CTL0 |= 0x4;//dataoutΪ1

	while(1)
	{ 
		CTL0 &= 0xFFFFFFFA;//dataoutΪ0
		delay(100);
		CTL0 |= 0x4;//dataoutΪ1
		delay(5000);
	}    

}


