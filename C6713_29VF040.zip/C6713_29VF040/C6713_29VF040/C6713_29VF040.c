#define	CHIP_6713 1

#include <csl.h>
#include <csl_emif.h>
#include <csl_irq.h>
#include <stdio.h>

#include "TESTDRAM.h"
 
#define PLLCSR  *((Uint32*)0x01B7C100)
#define PLLM    *((Uint32*)0x01B7C110)
#define PLLDIV0 *((Uint32*)0x01B7C114)	//REF CLOCK
#define PLLDIV1 *((Uint32*)0x01B7C118)	//CPU CLOCK
#define PLLDIV2 *((Uint32*)0x01B7C11C)	//PER CLOCK
#define PLLDIV3 *((Uint32*)0x01B7C120)	//EMIF CLOCK
#define OSCDIV1 *((Uint32*)0x01B7C124)	//SYS CLOCK

#define FLASH_ADR1                (0x90000000+(0x555)) 
#define FLASH_ADR2                (0x90000000+(0x2aa)) 
#define FLASH_ADR3                 0x90000000  
#define FLASH_ADR4                (0x90000000+(0x01)) 

#define SST_29VF040                0x14

#define PStart 0x00000000
#define DStart 0x80000000

void EraseFlash(void);
void ProgramFlash (int * sourcepoint, Uint32 flashpoint,unsigned int j);
int Program_One_Word (Uint8 *SrcWord,   Uint32 Dst);
void delay(int ttt)//uint 100us
{
	int i,j;
	for(i=0;i<ttt;i++)
	{
		for(j=0;j<2000;j++)	//1716
			asm(" nop ");
	}
}

void InitEmif()
{
	EMIF_Config emif_cfg = {
	  0x00003778, /* gblctl */
	  0xffffff33, /* cectl0 */
	  0xffffff03, /* cectl1 */
	  0xffffff43, /* cectl2 */
	  0xffffff13, /* cectl3 */
	  0x57116000, /* sdctl  */
	  0x00000400, /* sdtim  */
	  0x00000000  /* sdext  */
	};

	EMIF_config(&emif_cfg);
}

void main()
{
	Uint8 	SST_id1;              /* get first ID word               */ 
	int flashburn=0;

   	CSL_init();
	InitEmif();

//	*(unsigned int *)(0x90000004) = 0xFFFFFF13;	
	*(volatile char *)FLASH_ADR1= 0xAA;                  

	*(volatile char *)FLASH_ADR2= 0x55;                 
	*(volatile char *)FLASH_ADR1= 0x90;                

	asm(" NOP 9 "); 

	SST_id1  =  *(volatile char *)FLASH_ADR4;              
//	SST_id1  =  SST_id1 & 0xFF;     
//	SST_id2  =  *(volatile short *)FLASH_ADR4;            

	*(volatile char *)FLASH_ADR1= 0xAA;                  

	*(volatile char *)FLASH_ADR2= 0x55;                  
	*(volatile char *)FLASH_ADR1= 0xF0;
		
	printf("%x\n",SST_id1);

	EraseFlash();	
	if(flashburn==0)
	{
	    ProgramFlash (TESTDRAM, 0x90000000, 0x500);
	}
	printf("flash is over!");
}


void EraseFlash(void)
{
	/* Code to erase XXX
	 * 4MBit (256K X 8) Flash Memory
	 */
	*(volatile char *)FLASH_ADR1 = 0xaa;		//AAH
	*(volatile char *)FLASH_ADR2 = 0x55;		//55H
	*(volatile char *)FLASH_ADR1 = 0x80;		//80H

	*(volatile char *)FLASH_ADR1 = 0xaa;		//AAH
	*(volatile char *)FLASH_ADR2 = 0x55;		//55H
	*(volatile char *)FLASH_ADR1 = 0x10;		//10H
	
	/* Spin here 'til erasing completes
	 */
	delay(1000);			
	return;
}

void ProgramFlash (int *sourcepoint, Uint32 flashpoint,unsigned int j)
{
     unsigned int i;
	 int temp;
	 Uint16 temp1,temp2; 
	 Uint8 temp11,temp12,temp21,temp22;

     for(i=0 ;i< j*4; i+=4)
     {
       	temp = (*sourcepoint++);
		temp1 = temp & 0xffff;
		temp2 = (temp & 0xffff0000) >> 16;
		temp11 = temp1 & 0xff;
		temp12 = (temp1 & 0xff00) >> 8;
		temp21 = temp2 & 0xff;
		temp22 = (temp2 & 0xff00) >> 8; 
  		Program_One_Word(&temp11,flashpoint+1*i);
		Program_One_Word(&temp12,flashpoint+1*(i+1));
		Program_One_Word(&temp21,flashpoint+1*(i+2));
		Program_One_Word(&temp22,flashpoint+1*(i+3));       
		
     } 
}

int Program_One_Word (Uint8 *SrcWord,   Uint32 Dst)
{
   
    int ReturnStatus;

   *((unsigned char *)FLASH_ADR1) = 0xAA;

   *((unsigned char *)FLASH_ADR2) = 0x55;

   *((unsigned char *)FLASH_ADR1) = 0xA0;
    *(volatile char *)Dst = *SrcWord; // transfer the Uint16 to destination
	delay(50);
   ReturnStatus = 1;

    return ReturnStatus;
}
