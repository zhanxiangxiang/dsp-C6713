Run the following to rebuild the DSP program:

cl6x -@options

The result is a C6x executable file CnfDSP_nohost.out.  

The DSP program CnfDSP_nohost.out was designed to run 
WITHOUT a Host Program.  This can be compared to the 
program CnfDSP.out, which expects Host Commands.

