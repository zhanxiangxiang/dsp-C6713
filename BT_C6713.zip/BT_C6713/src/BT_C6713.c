#define	CHIP_6713 1

#include <csl.h>
#include <csl_emif.h>
#include <csl_irq.h>
#include <stdio.h>
#include <csl_gpio.h>


#define PLLCSR  *((Uint32*)0x01B7C100)
#define PLLM    *((Uint32*)0x01B7C110)
#define PLLDIV0 *((Uint32*)0x01B7C114)	//REF CLOCK
#define PLLDIV1 *((Uint32*)0x01B7C118)	//CPU CLOCK
#define PLLDIV2 *((Uint32*)0x01B7C11C)	//PER CLOCK
#define PLLDIV3 *((Uint32*)0x01B7C120)	//EMIF CLOCK
#define OSCDIV1 *((Uint32*)0x01B7C124)	//SYS CLOCK

GPIO_Handle hGpio;

void delay(int ttt)
{
	int i,j;
	for(i=0;i<ttt;i++)
	{
		for(j=0;j<2000;j++)	
			asm(" nop ");
	}
}

interrupt void eint4_isr()
{
	IRQ_disable(IRQ_EVT_EXTINT4);

	printf("EINT4 Test OK!\n");

	IRQ_clear(IRQ_EVT_EXTINT4);
	IRQ_enable(IRQ_EVT_EXTINT4);
}

interrupt void eint5_isr()
{
	IRQ_disable(IRQ_EVT_EXTINT5);

	printf("EINT5 Test OK!\n");

	IRQ_clear(IRQ_EVT_EXTINT5);
	IRQ_enable(IRQ_EVT_EXTINT5);
}

interrupt void eint6_isr()
{
	IRQ_disable(IRQ_EVT_EXTINT6);

	printf("EINT6 Test OK!\n");

	IRQ_clear(IRQ_EVT_EXTINT6);
	IRQ_enable(IRQ_EVT_EXTINT6);
}

interrupt void eint7_isr()
{
	IRQ_disable(IRQ_EVT_EXTINT7);

	printf("EINT7 Test OK!\n");

	IRQ_clear(IRQ_EVT_EXTINT7);
	IRQ_enable(IRQ_EVT_EXTINT7);
}

void InitInterrupts()
{
	IRQ_setVecs((void *)0x00);
    IRQ_nmiEnable();
	IRQ_globalEnable();
    
	IRQ_disable(IRQ_EVT_EXTINT4);
	IRQ_clear(IRQ_EVT_EXTINT4);
	IRQ_enable(IRQ_EVT_EXTINT4);

	IRQ_disable(IRQ_EVT_EXTINT5);
	IRQ_clear(IRQ_EVT_EXTINT5);
	IRQ_enable(IRQ_EVT_EXTINT5);

	IRQ_disable(IRQ_EVT_EXTINT6);
	IRQ_clear(IRQ_EVT_EXTINT6);
	IRQ_enable(IRQ_EVT_EXTINT6);

	IRQ_disable(IRQ_EVT_EXTINT7);
	IRQ_clear(IRQ_EVT_EXTINT7);
	IRQ_enable(IRQ_EVT_EXTINT7);
}

void InitEmif()
{
	EMIF_Config emif_cfg = {
	  0x00003778, /* gblctl */
	  0xffffff33, /* cectl0 */
	  0xffffff03, /* cectl1 */
	  0xffffff43, /* cectl2 */
	  0xffffff13, /* cectl3 */
	  0x57116000, /* sdctl  */
	  0x00000400, /* sdtim  */
	  0x00000000  /* sdext  */
	};

	EMIF_config(&emif_cfg);
}

void InitGPIO()
{
	hGpio = GPIO_open(GPIO_DEV0,GPIO_OPEN_RESET);
	GPIO_configArgs(hGpio,
					0x00000000, // gpgc 
					0x00000000, // gpen 
					0x00000000, // gdir 
					0x00000000, // gpval 
					0x00000000, // gphm 
					0x00000000, // gplm 
					0x00000000  // gppol 
					);

	GPIO_pinEnable(hGpio,GPIO_PIN4 |GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
	GPIO_pinDirection(hGpio,GPIO_PIN4 | GPIO_PIN5|GPIO_PIN6|GPIO_PIN7,GPIO_INPUT);
	GPIO_intPolarity(hGpio,GPIO_GPINT4,GPIO_FALLING);
	GPIO_intPolarity(hGpio,GPIO_GPINT5,GPIO_FALLING);
	GPIO_intPolarity(hGpio,GPIO_GPINT6,GPIO_FALLING);
	GPIO_intPolarity(hGpio,GPIO_GPINT7,GPIO_FALLING);

	GPIO_maskLowSet (hGpio,GPIO_PIN4 | GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
	GPIO_maskHighSet (hGpio,GPIO_PIN4 | GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
}

void InitPLL()
{
	//ǰ���д���ΪFT-C6713��FT-C6713J/250��FT-C6713SPFר�ã�FT-C6713J/400����Ҫ�����������TI-C6713��ͬ��

	PLLCSR &= 0x000000fe; // bypass PLL
	delay(2000); // wait 2000 nops

	PLLCSR |= 0x00000002; // power down PLL
	delay(2000); // wait 2000 nops

	//����Ĵ����û����ñ�Ƶ�ͷ�Ƶ���û��ɸ�����Ҫ����ʱ��Ƶ�ʣ���ʾ������ʱ��
	//����Ϊ8 ��Ƶ

	PLLDIV0 = 0x00008000; // PLLREF=24MHz/1=24MHz
	PLLM = 0x00000008; // PLLOUT=24MHz*8=192MHz
	OSCDIV1 = 0x0000001f; // CLKOUT3=24MHz/32=750KHz

	PLLDIV3 = 0x00008001; // ECLKOUT=192MHz/2=96MHz
	delay(2000); // wait 2000 nops

	PLLDIV2 = 0x00008001; // SYSCLK2=192MHz/2=96MHz
	delay(2000); // wait 2000 nops

	PLLDIV1 = 0x00008000; // SYSCLK1=192MHz/1=192MHz
	delay(2000); // wait 2000 nops

	//�������д���ʹPLL ���븴λ��ʹ��PLL
	PLLCSR = 0x00000000; // bring PLL out of reset
	delay(2000); // wait 2000 nops

	PLLCSR = 0x00000001; // enable PLL
}

void main()
{
	Uint32	A;
	Uint32*	pAddr;
	Uint32	error;

	CSL_init();
	InitPLL();
	InitEmif();
	InitGPIO();
	InitInterrupts();

	while(1)
	{
//---------------------------------------------------------------------------
//EMIF MEM TEST

		printf("Test SDRAM...\n");
		printf("Write...\n");
		error=0;
		for(A=0x80000000;A<0x81000000;A+=4)
		{
			pAddr=(Uint32*)(A);
			*pAddr=(A-0x80000000)>>2;
		}
		printf("Verify...\n");
		for(A=0x80000000;A<0x81000000;A+=4)
		{
			pAddr=(Uint32*)(A);
			if( (*pAddr)!=((A-0x80000000)>>2))
			{
				printf("SDRAM Error at 0x%08x\n",A);
				error=1;
				break;
			}
		}
		if(error)
			printf("Found SDRAM error!\n\n");
		else
			printf("SDRAM Test OK!\n\n");
    }
}


